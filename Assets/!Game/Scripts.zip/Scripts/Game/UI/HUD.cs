using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using TMPro;
using Zenject;
using Game.Contracts;
using Game.LocalizationSystem;

namespace Game
{
    public class HUD : MonoBehaviour, IDisposable
    {
        [SerializeField] private Transform _content;
        [SerializeField] private CubeView _cubeViewTemplate;
        [SerializeField] private TextMeshProUGUI _text;
        [SerializeField] private ScrollRect _scrollRect;
        [SerializeField] private RectTransform _scrollRectTrasnsform;
        [SerializeField] private float _delay = 2f;

        private WaitForSeconds _wait;
        private Coroutine _coroutine;
        private Tower _tower;
        
        public float HeightScroll => _scrollRectTrasnsform.rect.height;
        
        [Inject]
        public void Construct(Tower tower, IGameConfigProvider cubeData)
        {
            _tower = tower;
            _wait = new WaitForSeconds(_delay);
            List<GameConfigData> configs = new(cubeData.GetConfigs());
            
            foreach (GameConfigData info in configs)
                Instantiate(_cubeViewTemplate, _content).Construct(info);

            _tower.OnAddedCube += ShowSetCubeText;
            _tower.OnReachedLimit += ShowReachedLimitText;
        }

        public void Dispose()
        {
            _tower.OnAddedCube -= ShowSetCubeText;
            _tower.OnReachedLimit -= ShowReachedLimitText;
            
            if (this == null) return;
            StopAllCoroutines();
            _coroutine = null;
        }

        public void ShowSetCubeText()
        {
            Dispose();
            _coroutine ??= StartCoroutine(ShowText("SET_CUBE"));
        }
        
        public void ShowThrowAwayCubText()
        {
            Dispose();
            _coroutine ??= StartCoroutine(ShowText("THROW_AWAY_CUBE"));
        }
        
        public void ShowCubeDisappearingText()
        {
            Dispose();
            _coroutine ??= StartCoroutine(ShowText("CUBE_DISAPPEAR"));
        }
        
        public void ShowReachedLimitText()
        {
            Dispose();
            _coroutine ??= StartCoroutine(ShowText("REACHED_LIMIT"));
        }

        public void StopScroll()
        {
            _scrollRect.OnEndDrag(
                new PointerEventData(EventSystem.current)
            );

            _scrollRect.velocity = Vector2.zero;
        }

        private IEnumerator ShowText(string key)
        {
            _text.text = Localization.GetTranslate(key);
            _text.enabled = true;
            yield return _wait;
            _text.enabled = false;
            _coroutine = null;
        }
    }
}