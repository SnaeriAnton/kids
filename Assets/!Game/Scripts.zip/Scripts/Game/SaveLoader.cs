using System.Collections.Generic;
using System.Linq;
using Zenject;
using Game.Contracts;
using Game.SaveSystem;

namespace Game
{
    public class SaveLoader : IInitializable
    {
        private readonly Factory _factory;
        private readonly Tower _tower;
        private readonly IGameConfigProvider _cubeData;

        public SaveLoader(Tower tower, Factory factory, IGameConfigProvider cubeData)
        {
            _tower = tower;
            _factory = factory;
            _cubeData = cubeData;
        }
        
        public void Initialize()
        {
            if (SaveManager.Data.Cubes == null) return;
            
            List<GameConfigData> configs = new(_cubeData.GetConfigs());
            
            foreach (SaveSystem.CubeData data in SaveManager.Data.Cubes)
            {
                GameConfigData confData = configs.First(c => c.ID == data.CubeID);
                Cube cube = _factory.Create(confData, data.Position.AsVec());
                _tower.AddCube(cube);
            }
        }
    }
}