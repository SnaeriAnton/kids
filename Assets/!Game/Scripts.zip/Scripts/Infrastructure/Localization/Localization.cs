using System;
using System.Collections.Generic;

namespace Game.LocalizationSystem
{
    public static class Localization
    {
        private static Dictionary _dictionary;

        public static LanguageCodes Language = LanguageCodes.Default;

        public static event Action<LanguageCodes> Translated;

        public static void Construct(Dictionary dictionary, LanguageCodes code)
        {
            _dictionary = dictionary;
            SetLanguage(code);
        }

        public static void SetLanguage(LanguageCodes code)
        {
            Language = code;
            _dictionary.Init();
            Translated?.Invoke(Language);
        }

        public static string GetTranslate(string key)
        {
            WordData data = _dictionary.GetTranslate(key);

            switch (Language)
            {
                case LanguageCodes.ru:
                    return data.RU;
                case LanguageCodes.en:
                    return data.EN;
            }

            throw new KeyNotFoundException();
        }

        public static void Translate() => Translated?.Invoke(Language);
    }
}