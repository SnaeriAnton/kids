using UnityEngine;
using Zenject;
using Game.Contracts;

namespace Game.InputSystem
{
    public class InputRoot : MonoBehaviour
    {
        private IInputRoot _input;
        public IInput Input => _input;
        
        [Inject]
        public void Construct(IInput input) => _input = input as IInputRoot;

        // [Inject]
        // public void Construct() => _input =  Application.isMobilePlatform ? new Mobile() : new PC();
        
        private void Update() => _input?.Update();
    }
}
