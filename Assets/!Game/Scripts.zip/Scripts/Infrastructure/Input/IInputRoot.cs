using Game.Contracts;

namespace Game.InputSystem
{
    public interface IInputRoot : IUpdatable, IInput { }
}
