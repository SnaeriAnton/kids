using System;
using Newtonsoft.Json;
using UnityEngine;

namespace Game.SaveSystem
{
    public class SaveManager
    {
        private const string KEY_SAVE = "KEY_SAVE";

        public static PlayerData Data { get; private set; }

        public static void Load()
        {
            if (PlayerPrefs.HasKey(KEY_SAVE))
                Data = JsonConvert.DeserializeObject<PlayerData>(PlayerPrefs.GetString(KEY_SAVE));
            else
                Data = new();
        }

        public static void Save() => PlayerPrefs.SetString(KEY_SAVE, JsonConvert.SerializeObject(Data));
    }
}